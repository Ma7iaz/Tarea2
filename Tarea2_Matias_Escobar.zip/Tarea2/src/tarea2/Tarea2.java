package tarea2;
import java.util.ArrayList;
import java.util.Scanner;

public class Tarea2 {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        Expendedor exp = new Expendedor(1, 500);
        Comprador aux = null;
        Moneda m1000 = new Moneda1000();
        Moneda m500 = new Moneda500();
        Moneda m100 = new Moneda100();
        System.out.println("Ingrese el numero de la bebida que desea comprar: \nCosto de cada una: $500\n1. Coca-Cola 2. Sprite 3. Fanta");
        int beb_ele = entrada.nextInt();
        System.out.println("Ingrese el numero de la moneda con la que va a pagar: \n1. $1000 2. $500 3. $100");
        int mon_ele = entrada.nextInt();
        switch (mon_ele) {
            case 1: { Comprador comp = new Comprador(m1000, beb_ele, exp);
                      aux = comp;
                      break; }
            case 2: { Comprador comp = new Comprador(m500, beb_ele, exp);
                      aux = comp;
                      break; }
            case 3: { Comprador comp = new Comprador(m100, beb_ele, exp);
                      aux = comp;
                      break; }
            default:
                    break;
        }
        System.out.println("Qué bebiste: "+aux.queBebiste());
        System.out.println("Vuelto recibido: "+aux.cuantoVuelto());
    }
}
class Comprador {
    private int vueltoTotal;
    private String queBebida;
    public Comprador(Moneda m, int cualBebida, Expendedor exp) {
        try {
            Bebida b = exp.comprarBebida(m, cualBebida);
            if(b!=null) queBebida = b.beber();
            Moneda mon;
            while((mon=exp.getVuelto()) != null) {
                vueltoTotal += mon.getValor();
            }
        } catch (PagoInsuficienteException | NoHayBebidaException | PagoIncorrectoException e) {
            System.out.println(e.getMessage());
        }
        //System.out.println("Qué bebiste: "+this.queBebiste());
        //System.out.println("Vuelto recibido: "+this.cuantoVuelto());
    }
    public int cuantoVuelto() {
        return vueltoTotal;
    }
    public String queBebiste() {
        return queBebida;
    }
}
class NoHayBebidaException extends Exception {
    public NoHayBebidaException(String errorMessage) {
        super(errorMessage);
    }
}
class PagoInsuficienteException extends Exception {
    public PagoInsuficienteException(String errorMessage) {
        super(errorMessage);
    }
}
class PagoIncorrectoException extends Exception {
    public PagoIncorrectoException(String errorMessage) {
        super(errorMessage);
    }
}
class Expendedor {
    private Deposito coca;
    private Deposito sprite;
    private Deposito fanta;
    private DepositoVuelto depV;
    private int precioBebidas;
    public static final int COCA = 1;
    public static final int SPRITE = 2;
    public static final int FANTA = 3;
    public Expendedor(int numBebidas, int precioBebidas) {
        coca = new Deposito();
        sprite = new Deposito();
        fanta = new Deposito();
        depV = new DepositoVuelto();
        this.precioBebidas = precioBebidas;
        for(int n = 0; n < numBebidas; n++) {
            Bebida b = new CocaCola(n);
            coca.addBebida(b);
        }
        for(int n = 0; n < numBebidas; n++) {
            Bebida b = new Sprite(n);
            sprite.addBebida(b);
        }
        for(int n = 0; n < numBebidas; n++) {
            Bebida b = new Fanta(n);
            fanta.addBebida(b);
        }
    }
    public Bebida comprarBebida(Moneda m, int cual) throws NoHayBebidaException, PagoInsuficienteException, PagoIncorrectoException {
        if(m==null) {
            depV.addMoneda(m);
            throw new PagoIncorrectoException("Pago incorrecto, moneda no ingresada");
        } else if(cual!=COCA && cual!=SPRITE && cual!=FANTA && m!=null) {
            depV.addMoneda(m);
            throw new NoHayBebidaException("Numero de bebida seleccionado invalido");
        } else if(cual==COCA && m!=null) {
            if(coca.al.size()==0) {
                depV.addMoneda(m);
                throw new NoHayBebidaException("No quedan bebidas de las seleccionadas en el expendedor");
            } else {
                if(m.getValor() >= precioBebidas) {
                    int mon = (m.getValor()-precioBebidas)/100;
                    for(int n = 0; n < mon; n++) {
                        Moneda mo = new Moneda100();
                        depV.addMoneda(mo);
                    }
                    return coca.getBebida();
                } else {
                    depV.addMoneda(m);
                    throw new PagoInsuficienteException("Pago insuficiente");
                }
            }
        } else if(cual==SPRITE && m!=null) {
            if(sprite.al.size()==0) {
                depV.addMoneda(m);
                throw new NoHayBebidaException("No quedan bebidas de las seleccionadas en el expendedor");
            } else {
                if(m.getValor() >= precioBebidas) {
                    int mon = (m.getValor()-precioBebidas)/100;
                    for(int n = 0; n < mon; n++) {
                        Moneda mo = new Moneda100();
                        depV.addMoneda(mo);
                    }
                    return sprite.getBebida();
                } else {
                    depV.addMoneda(m);
                    throw new PagoInsuficienteException("Pago insuficiente");
                }
            }
        } else if(cual==FANTA && m!=null) {
            if(fanta.al.size()==0) {
                depV.addMoneda(m);
                throw new NoHayBebidaException("No quedan bebidas de las seleccionadas en el expendedor");
            } else {
                if(m.getValor() >= precioBebidas) {
                    int mon = (m.getValor()-precioBebidas)/100;
                    for(int n = 0; n < mon; n++) {
                        Moneda mo = new Moneda100();
                        depV.addMoneda(mo);
                    }
                    return fanta.getBebida();
                } else {
                    depV.addMoneda(m);
                    throw new PagoInsuficienteException("Pago insuficiente");
                }
            }
        } else {
            depV.addMoneda(m);
            return null;
        }
    }
    public Moneda getVuelto() {
        return depV.getMoneda();
    }
}
class Deposito {
    ArrayList<Bebida> al;
    public Deposito() {
        al = new ArrayList<Bebida>();
    }
    public void addBebida(Bebida b) {
        al.add(b);
    }
    public Bebida getBebida() {
        if(al.size() > 0) {
            Bebida b = al.remove(0);
            return(b);
        } else {
            return null;
        }
    }
}
class DepositoVuelto {
    private ArrayList<Moneda> al;
    public DepositoVuelto() {
        al = new ArrayList<Moneda>();
    }
    public void addMoneda(Moneda m) {
        al.add(m);
    }
    public Moneda getMoneda() {
        if(al.size() > 0) {
            Moneda m = al.remove(0);
            return (m);
        } else {
            return null;
        }
    }
}
abstract class Bebida {
    private int serie;
    public Bebida(int numserie){
        serie = numserie;
    }
    public int getSerie(){
        return serie;
    }
    public abstract String beber();
}
class CocaCola extends Bebida {
    public CocaCola(int serie) {
        super(serie);
    }
    public String beber() {
        return "cocacola";
    }
}
class Sprite extends Bebida {
    public Sprite(int serie) {
        super(serie);
    }
    public String beber() {
        return "sprite";
    }
}
class Fanta extends Bebida {
    public Fanta(int serie) {
        super(serie);
    }
    public String beber() {
        return "fanta";
    }
}
abstract class Moneda {
    public Moneda() {}
    public String getSerie() {
        return this.getSerie();
    }
    public abstract int getValor();
}
class Moneda1000 extends Moneda {
    public Moneda1000() {
        super();
    }
    public int getValor() {
        return 1000;
    }
}
class Moneda500 extends Moneda {
    public Moneda500() {
        super();
    }
    public int getValor() {
        return 500;
    }
}
class Moneda100 extends Moneda {
    public Moneda100() {
        super();
    }
    public int getValor() {
        return 100;
    }
}